package com.ytbackground;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import static com.ytbackground.MainActivity.pausePlay;

public class NotificationActionReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String actionName = intent.getStringExtra("actionName");

        if(actionName==null) actionName="";
        if(actionName.equals("pausePlay"))
            pausePlay();
        Log.d("debug-ac","action "+actionName);
    }
}